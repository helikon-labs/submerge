export const v16 = {
    // actual v16 definition
    MetadataV16: {
        lookup: 'PortableRegistry',
        pallets: 'Vec<PalletMetadataV16>',
        extrinsic: 'ExtrinsicMetadataV16',
        apis: 'Vec<RuntimeApiMetadataV16>',
        outerEnums: 'OuterEnums15',
        custom: 'CustomMetadata15'
    },
    // ---- Pallet definitions ----
    PalletMetadataV16: {
        name: 'Text',
        storage: 'Option<PalletStorageMetadataV16>',
        calls: 'Option<PalletCallMetadataV16>',
        events: 'Option<PalletEventMetadataV16>',
        constants: 'Vec<PalletConstantMetadataV16>',
        errors: 'Option<PalletErrorMetadataV16>',
        associatedTypes: 'Vec<PalletAssociatedTypeMetadataV16>',
        viewFunctions: 'Vec<PalletViewFunctionMetadataV16>',
        index: 'u8',
        docs: 'Vec<Text>',
        // Deprecation info
        deprecationInfo: 'ItemDeprecationInfoV16'
    },
    PalletStorageMetadataV16: {
        prefix: 'Text',
        items: 'Vec<StorageEntryMetadataV16>'
    },
    StorageEntryMetadataV16: {
        name: 'Text',
        modifier: 'StorageEntryModifierV14',
        type: 'StorageEntryTypeV14',
        fallback: 'Bytes',
        docs: 'Vec<Text>',
        deprecationInfo: 'ItemDeprecationInfoV16'
    },
    ItemDeprecationInfoV16: {
        _enum: {
            // Item is not deprecated.
            NotDeprecated: 'Null',
            // Item is fully deprecated without a note.
            DeprecatedWithoutNote: 'Null',
            // Item is fully deprecated with a note and an optional `since` field.
            Deprecated: {
                // Note explaining the deprecation
                note: 'Text',
                // Optional value for noting the version when the deprecation occurred.
                since: 'Option<Text>'
            }
        }
    },
    PalletCallMetadataV16: {
        type: 'SiLookupTypeId',
        // Deprecation status of the pallet call
        deprecationInfo: 'EnumDeprecationInfoV16'
    },
    // Deprecation information for enums in which specific variants can be deprecated.
    // If the map is empty, then nothing is deprecated.
    EnumDeprecationInfoV16: 'BTreeMap<u8, VariantDeprecationInfoV16>',
    VariantDeprecationInfoV16: {
        _enum: {
            // Dummy variant, just here to force DeprecatedWithoutNote
            // to have index 1 and Deprecated to have index 2
            DummyVariant: 'Null',
            // Variant is deprecated without a note.
            DeprecatedWithoutNote: 'Null',
            // Variant is deprecated with a note and an optional `since` field.
            Deprecated: {
                // Note explaining the deprecation
                note: 'Text',
                // Optional value for noting the version when the deprecation occurred.
                since: 'Option<Text>'
            }
        }
    },
    PalletEventMetadataV16: {
        type: 'SiLookupTypeId',
        // Deprecation info
        deprecationInfo: 'EnumDeprecationInfoV16'
    },
    PalletConstantMetadataV16: {
        name: 'Text',
        type: 'SiLookupTypeId',
        value: 'Bytes',
        docs: 'Vec<Text>',
        // Deprecation info
        deprecationInfo: 'ItemDeprecationInfoV16'
    },
    PalletErrorMetadataV16: {
        type: 'SiLookupTypeId',
        // Deprecation info
        deprecationInfo: 'EnumDeprecationInfoV16'
    },
    PalletAssociatedTypeMetadataV16: {
        name: 'Text',
        type: 'SiLookupTypeId',
        docs: 'Vec<Text>'
    },
    PalletViewFunctionMetadataV16: {
        id: '[u8; 32]',
        // Method name.
        name: 'Text',
        // Method par  ameters.
        inputs: 'Vec<RuntimeApiMethodParamMetadataV15>',
        // Method output.
        output: 'SiLookupTypeId',
        // Method documentation.
        docs: 'Vec<T::String>',
        // Deprecation info
        deprecationInfo: 'ItemDeprecationInfoV16'
    },
    // ---- Extrinsic definitions ----
    ExtrinsicMetadataV16: {
        // Extrinsic versions supported by the runtime.
        versions: 'Vec<u8>',
        // The type of the address that signs the extrinsic
        addressType: 'SiLookupTypeId',
        // The type of the outermost Call enum.
        callType: 'SiLookupTypeId',
        // The type of the extrinsic's signature.
        signatureType: 'SiLookupTypeId',
        // A mapping of supported transaction extrinsic versions to their respective transaction extension indexes.
        //
        // For each supported version number, list the indexes, in order, of the extensions used.
        transactionExtensionsByVersion: 'BTreeMap<u8, Vec<Compact<u32>>>',
        // The transaction extensions in the order they appear in the extrinsic.
        transactionExtensions: 'Vec<TransactionExtensionMetadataV16>'
    },
    TransactionExtensionMetadataV16: {
        // The unique transaction extension identifier, which may be different from the type name.
        identifier: 'Text',
        // The type of the transaction extension, with the data to be included in the extrinsic.
        type: 'SiLookupTypeId',
        // The type of the implicit data, with the data to be included in the signed payload.
        implicit: 'SiLookupTypeId'
    },
    // ---- Runtime Api definitions ----
    RuntimeApiMetadataV16: {
        name: 'Text',
        methods: 'Vec<RuntimeApiMethodMetadataV16>',
        docs: 'Vec<Text>',
        // Runtime API version.
        version: 'Compact<u32>',
        // Deprecation info
        deprecationInfo: 'ItemDeprecationInfoV16'
    },
    RuntimeApiMethodMetadataV16: {
        name: 'Text',
        inputs: 'Vec<RuntimeApiMethodParamMetadataV15>',
        output: 'SiLookupTypeId',
        docs: 'Vec<Text>',
        // Deprecation info
        deprecationInfo: 'ItemDeprecationInfoV16'
    }
};
